<script>
  import { slide } from "svelte/transition";
  //   let client = require("@mailchimp/mailchimp_marketing");

  var Mailchimp = require("mailchimp-api-v3");

  let images = "";

  let urls = "";

  let copiedToClipboardTxt = "";

  let uploading = false;

  let maxWidth = 600;
  let apiKey = "45e724548cccea8fdb0b210a35f5f563-us17";
  let serverPrefix = "us17";
  let connState;
  $: splitImages = images.trimEnd().split("\n");
  $: splitUrls = urls.trimEnd().split("\n");
  $: numOfCols = splitImages.length;
  $: colWidth = Math.round(
    maxWidth / numOfCols - (maxWidth / 10 / numOfCols) * 0.3 - 3
  );

  $: items = splitImages.map((i) => {
    let index = splitImages.indexOf(i);
    return { image: i, url: splitUrls[index] };
  });

  $: outputItems = items.map(
    (item) => `
	<a href="${item.url}" style="text-decoration: none; margin: 0; padding: 0;">
		<img src="${item.image}" style="display: inline-block; width: ${colWidth}px; margin: 0; padding: 0;" />
	</a>`
  );
  $: outputCode = `<div class="mcnTextContent" style="text-align: center; margin: 0; padding: 0;">${outputItems.join(
    ""
  )}\n</div>`;

  let outputTextArea;

  const selectCode = (e) => {
    outputTextArea.select();
    outputTextArea.setSelectionRange(0, 99999);
    document.execCommand("copy");
    copiedToClipboardTxt = "Copied to clipboard";
    setTimeout(() => (copiedToClipboardTxt = ""), 2000);
  };

  let previewDebug = false;

  const toBase64 = () => {
    let file = uploadElement.files[0];
    let reader = new FileReader();
    reader.onloadend = async () => {
      const readerResult = reader.result;
      currentBase64 = readerResult.substring(
        reader.result.indexOf("base64,") + 7
      );
      currentFileName = file.name;
    };
    reader.readAsDataURL(file);
  };

  const doUpload = async () => {
    // uploading = true;
    // let response = await client.fileManager.upload({
    //   name: currentFileName,
    //   file_data: currentBase64,
    // });
    const mailChimp = new Mailchimp(apiKey);
    mailChimp
      .post("/file-manager/files", {
        folder_id: 0,
        name: currentFileName,
        file_data: currentBase64,
      })
      .then((r) => {
        console.log(r);
        const newImageUrl = r.full_size_url;

        images += newImageUrl;
        images += "\n";
        urls += "#";
        urls += "\n";

        uploading = false;
        currentBase64 = null;
        currentFileName = null;
        uploadElement.value = "";
      });
  };

  let uploadElement;

  let currentBase64;
  let currentFileName;

  const testConnection = async (e) => {
    const response = await client.ping.get();
    connState = "✔ connected";
  };

  const setUp = () => {
    // client.setConfig({
    //   apiKey: apiKey,
    //   server: serverPrefix,
    // });
    // client.ping.get().then((r) => (connState = "✔ connected"));
    // client.ping.get().then((r) => (connState = "✔ connected"));

    const mailchimp = new Mailchimp(apiKey);
    mailchimp.get({ path: "/ping" }).then((r) => {
      console.log(r);
      if (r.statusCode === 200) connState = "✔ connected";
    });
  };
</script>

<style>
  @import url("https://fonts.googleapis.com/css2?family=Manrope:wght@400;700&display=swap");

  :global(html, body) {
    font-family: "Manrope", sans-serif;
  }

  .preview {
    border: 1px solid #bbb;
    border-radius: 6px;
    transition: 0.3s all;
  }

  :global(.preview a) {
    text-decoration: none;
  }

  :global(.preview img) {
    transition: 0.3s all;
  }

  :global(.mcnTextContent) {
    color: #202020;
    font-family: Helvetica;
    font-size: 16px;
    line-height: 150%;
    text-align: left;
  }

  textarea {
    font-family: monospace;
    font-size: 0.8rem;
    width: 100%;
    height: 100px;
    margin: 0.5rem 0;
    border-radius: 6px;
  }

  .output {
    width: 100%;
    height: 200px;
    border: none;
    font-size: 0.9rem;
    background: #fafafa;
    padding: 0.5rem;
    border-radius: 6px;
  }

  :global(.previewDebug img) {
    border: 1px solid green;
    border-radius: 4px;
  }
  .copiedToClipboardTxt {
    color: red;
  }

  :global(input[type="checkbox"]) {
    transform: scale(1.5);
  }

  .col-preview {
    border: 1px solid #eee;
    padding: 0.5rem;
    display: inline-flex;
    gap: 4px;
    margin: 1rem 0;
  }

  .col-preview .col {
    width: 4rem;
    height: 2rem;
    border: 1px solid #bbb;
    border-radius: 4px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  h1,
  h3,
  p {
    margin: 0;
    padding: 0;
  }

  h3 {
    margin-top: 1rem;
  }

  .flex {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 0.5rem auto;
    gap: 1rem;
  }

  label {
    margin: 0.25rem 0;
  }

  .error {
    background: crimson;
    color: #fff;
    padding: 0.5rem;
    border-radius: 6px;
  }
</style>

<h1>MailChimp multi-column helper</h1>

<p>Connection: {connState ?? '❌ not connected'}</p>

{#if connState == null}
  <h3>Setup</h3>

  <label for="apiKeyTxt">API key</label>
  <input type="text" id="apiKeyTxt" bind:value={apiKey} />

  <!-- <label for="srvrPrefixTxt">Server</label>
  <input type="text" id="srvrPrefixTxt" bind:value={serverPrefix} /> -->

  <br />

  <button on:click={setUp}>Set up connection</button>
{:else}
  <h3>Upload</h3>

  <label for="upload">Pick an image</label>
  <input
    type="file"
    id="upload"
    bind:this={uploadElement}
    on:change={toBase64} />
  <br />
  <p>{currentFileName}</p>
  <p>{currentBase64}</p>
  <br />

  <button disabled={uploading} on:click={doUpload}>Upload</button>

  <h3>Inputs</h3>

  <div class="flex">
    <label for="inputImages">Images</label>
    <label for="inputUrls">URLs</label>
    <textarea id="inputImages" bind:value={images} />
    <textarea id="inputUrls" bind:value={urls} />
  </div>

  <div style="display: flex; align-items: baseline; gap: 0.5rem;">
    <label for="maxWidth">Maximum width</label>
    <input
      id="maxWidth"
      type="number"
      min="1"
      max="1200"
      bind:value={maxWidth} />
    <label for="maxWidth">px</label>
  </div>

  {#if splitImages.length != splitUrls.length}
    <p transition:slide class="error">
      <b>Warning</b><br />Number of rows in both columns should be equal!
    </p>
  {/if}

  <h3>Code</h3>

  <small>Click to copy</small>
  <textarea
    bind:this={outputTextArea}
    class="output"
    type="text"
    readonly
    bind:value={outputCode}
    on:click={selectCode} />
  <p class="copiedToClipboardTxt">{copiedToClipboardTxt}</p>

  <h3 style="margin-bottom: 0.5rem">Preview</h3>
  <div
    transition:slide
    class="preview"
    class:previewDebug
    style="width: {maxWidth}px">
    {@html outputCode}
  </div>

  <div class="col-preview">
    {#each new Array(numOfCols) as item, i (i)}
      <div transition:slide class="col">{colWidth}px</div>
    {/each}
  </div>

  <br />
  <label for="previewDebug"><input
      id="previewDebug"
      type="checkbox"
      bind:checked={previewDebug} /> &nbsp;&nbsp;Preview debug</label>
{/if}
